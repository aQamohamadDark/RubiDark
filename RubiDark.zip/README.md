# Rubika Client for python 3

<div align="center">


# install 

```pip install RubiDark```

# exmaple 

```python 
from RubiDark.client import RoBoT

BoT = RoBoT("")
```

# dark